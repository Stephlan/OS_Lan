#include "../../tool/tool.h"
#include "../../arch/arch.h"
#include "../mm/bootmm.h"
#include "print.h"
#include "vga.h"

struct vga_attr vga;

void init_vga()
{
	unsigned char *area;

	area = bootmm_alloc_pages(VGA_MAX_COL * VGA_MAX_ROW * sizeof(short),
		_MM_VGABUFF, 0x10000);
	//if (!area)
	//	die();
	
	vga.cursor_row = 0;
	vga.cursor_col = 0;
	vga.vga_buffer = (short *)area;
	vga.io_vga_ctrl = (unsigned int *)_IO_VGA_CTRL;
	vga.io_vga_buff = (unsigned int *)_IO_VGA_BUFF;
	vga.io_vga_cursor = (unsigned int *)_IO_VGA_CURS;
	vga.io_vga_flash = (unsigned int *)_IO_VGA_FLASH;

	init_lock(&(vga.vga_lock));
	clean_screen(VGA_MAX_ROW);
	*(vga.io_vga_flash) = mkint(0x8000, 1000); // 500ms��˸һ�ι��
	*(vga.io_vga_buff) = (unsigned int)area;
	*(vga.io_vga_ctrl) = mkint(0x4000, 1); // �ı�ģʽ, ����Ӳ�����

	printk("Setup vga ok :\n");
	printk("\tusing TEXT mode\n");
	printk("\tenable hardware cursor\n");
	printk("\tbuffer start at %x\n", *(vga.io_vga_buff));
}

/*
* �����Ļ������
*/
void clean_screen(unsigned int scope)
{
	unsigned int r, c;
	short *buffer = vga.vga_buffer;
	short val = mkshort((COLOR_BLACK << 4) | COLOR_BLACK, 0);
	
	for (r = 0; r < scope; ++r) {
		for (c = 0; c < VGA_MAX_COL; ++c) {
			*buffer = val;
			++buffer;
		}
	}
	set_cursor(0, 0);
}

/*
* ����Ӳ������λ��
*/
void set_cursor(short row, short col)
{
	vga.cursor_row = (row & 0x0000ffff);
	vga.cursor_col = (col & 0x0000ffff);
	*(vga.io_vga_cursor) = mkint(vga.cursor_row, vga.cursor_col);
}

/*
* ���Ϸ���һ��
*/
void scroll_screen(unsigned int scope)
{
	unsigned int r, c_len;
	
	if (!vga.cursor_row) // ֻ��һ�еĻ����Ǳ𷭹���
		return;
	
	c_len = multiply(sizeof(short), VGA_MAX_COL);
	for (r = 0; r < (scope- 1); ++r) {
		memcpy(vga.vga_buffer + multiply(r, VGA_MAX_COL), 
			vga.vga_buffer + multiply(r + 1, VGA_MAX_COL), c_len);
	}
	memset(vga.vga_buffer + multiply(r, VGA_MAX_COL), 0, c_len);
	set_cursor(vga.cursor_row - 1, vga.cursor_col); // ��Ӧ�ģ����ҲҪ�����ƶ�һ��
}

/*
* ����Ļ�����һ���ַ�
*/
void put_char_ex(unsigned int ch, unsigned int bg, unsigned int fg, unsigned int row, unsigned int col, unsigned int scope)
{
	short val = mkshort((bg << 4) | fg, ch);
	short *position;
	
	if (row >= scope)
		row = scope - 1;
	if (col >= VGA_MAX_COL)
		col = VGA_MAX_COL - 1;

	lockup(&(vga.vga_lock));
	position = vga.vga_buffer + multiply(row, VGA_MAX_COL) + col;
	*position = val;
	unlock(&(vga.vga_lock));
}

void put_char(unsigned int ch, unsigned int bg, unsigned int fg, unsigned int scope)
{
	short val = mkshort((bg << 4) | fg, ch);
	short *position;

	lockup(&(vga.vga_lock));
	if (ch == '\n') {
		vga.cursor_col = 0;
		++(vga.cursor_row);
		if (vga.cursor_row == scope) {
			scroll_screen(scope);
		} else {
			set_cursor(vga.cursor_row, vga.cursor_col);
		}
		goto out;
	}

	if (ch == '\t') {
		vga.cursor_col += VGA_TAB_LEN;
		if (vga.cursor_col >= VGA_MAX_COL) {
			vga.cursor_col = 0;
			++(vga.cursor_row);
		}
		if (vga.cursor_row == scope) {
			scroll_screen(scope);
		} else {
			set_cursor(vga.cursor_row, vga.cursor_col);
		}
		goto out;
	}
	
	position = vga.vga_buffer + multiply(vga.cursor_row & 0x0000ffff, VGA_MAX_COL) 
		+ vga.cursor_col;
	*position = val;
	++(vga.cursor_col);
	if (vga.cursor_col == VGA_MAX_COL) {
		vga.cursor_col = 0;
		++(vga.cursor_row);
	}
	if (vga.cursor_row == scope) {
		scroll_screen(scope);
	} else {
		set_cursor(vga.cursor_row, vga.cursor_col);
	}

out:
	unlock(&(vga.vga_lock));
}



