#ifndef _LCORE_SYSCALL_H
#define _LCORE_SYSCALL_H

#define V0_OFFSET 0

#define SYSCALL_DEFINE0(funname) \
	void funname(unsigned int *args)

#define SYSCALL_DEFINE1(funname, type1, arg1) \
	void funname(unsigned int *args, type1 arg1)

#define SYSCALL_DEFINE2(funname, type1, arg1, type2 , arg2) \
	void funname(unsigned int *args, type1 arg1, type2 arg2)

#define SYSCALL_DEFINE3(funname, type1, arg1, type2, arg2, type3, arg3) \
	void funname(unsigned int *args, type1 arg1, type2 arg2, type3 arg3)

#define MAX_SYSCALL 1024

extern void *syscall_table[MAX_SYSCALL];
extern void init_syscall();

#endif

