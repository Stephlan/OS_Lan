#include "../../arch/arch.h"
#include "../../tool/tool.h"
#include "buddy.h"
#include "slub.h"

struct kmem_cache kmalloc_caches[PAGE_SHIFT];

static unsigned int size_index[24] = {
	3, 4, 5, 5, 6, 6,
	6, 6, 1, 1, 1, 1,
	7, 7, 7, 7, 2, 2,
	2, 2, 2, 2, 2, 2
};

struct kmem_cache *get_slub(unsigned int size)
{
	if (size <= 192)
		return kmalloc_caches + size_index[(size - 1) >> 3];

	return kmalloc_caches + (highest_set(size - 1) + 1);
}

void init_kmem_cpu(struct kmem_cache_cpu *kcpu)
{
	kcpu->page = 0;
	kcpu->freeobj = 0;
}

void init_kmem_node(struct kmem_cache_node *knode)
{
	INIT_LIST_HEAD(&(knode->full));
	INIT_LIST_HEAD(&(knode->partial));
}

void init_each_slub(struct kmem_cache *cache, unsigned int size)
{
	cache->objsize = size;
	cache->objsize += (BYTES_PER_LONG - 1);
	cache->objsize &= ~(BYTES_PER_LONG - 1);
	cache->offset = cache->objsize;
	cache->size = cache->objsize + sizeof(void *);
	init_kmem_cpu(&(cache->cpu));
	init_kmem_node(&(cache->node));
}

void init_slub()
{
	unsigned int order;

	init_each_slub(&(kmalloc_caches[1]), 96);
	init_each_slub(&(kmalloc_caches[2]), 192);

	for (order = 3; order <= 11; ++order) {
		init_each_slub(&(kmalloc_caches[order]), 1 << order);
	}

	printk("Setup Slub ok :\n");
	printk("\t");
	for (order = 1; order < PAGE_SHIFT; ++order)
		printk("%x ", kmalloc_caches[order].objsize);
	printk("\n");
}

void format_slubpage(struct kmem_cache *cache, struct page *page)
{
	unsigned char *m = (unsigned char *)((page - pages) << PAGE_SHIFT);
	struct slub_head *s_head = (struct slub_head *)m;
	unsigned int remaining = 1 << PAGE_SHIFT;
	unsigned int *ptr;
	
	set_flag(page, _PAGE_SLUB);
	s_head->nr_objs = 0;
	do {
		ptr = (unsigned int *)(m + cache->offset);
		m += cache->size;
		*ptr = (unsigned int)m;
		remaining -= cache->size;
	} while (remaining >= cache->size);

	*ptr = (unsigned int)m & ~((1 << PAGE_SHIFT) - 1); //����ָ��ҳ��ʼλ�ã���ʾ����������
	s_head->end_ptr = ptr;
	s_head->nr_objs = 0;
	cache->cpu.page = page;
	cache->cpu.freeobj = (void **)(*ptr + cache->offset);
	page->private = (unsigned int)(*(cache->cpu.freeobj)); //��һ��obj�ĵ�ַ(�����ĵ�1������ΪԤ���ġ�����)
	page->virtual = (void *)cache;
}

void *slub_alloc(struct kmem_cache *cache)
{
	struct slub_head *s_head;
	void *object = 0;
	struct page *new;

	if (cache->cpu.freeobj)
		object = *(cache->cpu.freeobj);

check:
	if (is_bound((unsigned int)object, 1 << PAGE_SHIFT)) { //��ʱ�϶���freeobj == end
		if (cache->cpu.page) //��ô�϶�����Ϊ���slub����
			list_add_tail(&(cache->cpu.page->list), &(cache->node.full));

		if (list_empty(&(cache->node.partial)))
				goto new_slub;
		cache->cpu.page = container_of(cache->node.partial.next, 
			struct page, list);
		list_del(cache->node.partial.next);
		object = (void *)(cache->cpu.page->private);
		cache->cpu.freeobj = (void **)((unsigned char *)object + cache->offset);
		goto check;
	}

	cache->cpu.freeobj = (void **)((unsigned char *)object + cache->offset);
	cache->cpu.page->private = (unsigned int)(*(cache->cpu.freeobj));
	s_head = (struct slub_head *)((cache->cpu.page - pages) << PAGE_SHIFT);
	++(s_head->nr_objs);
	if (is_bound(cache->cpu.page->private, 1 << PAGE_SHIFT)) { // ���slub��������
		list_add_tail(&(cache->cpu.page->list), &(cache->node.full));
		init_kmem_cpu(&(cache->cpu));
	}
	return object;

new_slub:
	
	new = __alloc_pages(0);
	if (!new) {
		printk("ERROR : slub_alloc error!\n");
		die();
	}

	format_slubpage(cache, new);
	object = *(cache->cpu.freeobj);
	goto check;
}

void slub_free(struct kmem_cache * cache, void *obj)
{
	struct page *page = pages + ((unsigned int)obj >> PAGE_SHIFT);
	struct slub_head *s_head = (struct slub_head *)((page - pages) << PAGE_SHIFT);
	unsigned int *ptr;

	if (!(s_head->nr_objs)) {
		printk("ERROR : slub_free error!\n");
		die();
	}
	
	ptr = (unsigned int *)((unsigned char *)obj + cache->offset);
	*ptr = *((unsigned int *)(s_head->end_ptr));
	*((unsigned int *)(s_head->end_ptr)) = (unsigned int)obj;
	--(s_head->nr_objs);
	
	if (list_empty(&(page->list))) //���page��cpu�ϣ�����node��
		return;

	if (!(s_head->nr_objs)) {
		__free_pages(page, 0);
		return;
	}

	
	list_del_init(&(page->list));
	list_add_tail(&(page->list), &(cache->node.partial));
}

void *kmalloc( unsigned int size)
{
	struct kmem_cache *cache;
	void *ptr;
	
	if (!size)
		return 0;

	if (size > kmalloc_caches[PAGE_SHIFT - 1].objsize) {
		size += ((1 << PAGE_SHIFT) - 1);
		size &= ~((1 << PAGE_SHIFT) - 1);
		ptr = alloc_pages(size >> PAGE_SHIFT);
		memset(ptr, 0, (size+(PAGE_SIZE-1))&(~(PAGE_SIZE-1)));
		return ptr;
	}

	cache = get_slub(size);
	if (!cache) {
		printk("ERROR : kmalloc error!\n");
		die();
	}

	ptr = slub_alloc(cache);
	memset(ptr, 0, size);
	return ptr;
}


void kfree(void *obj)
{
	struct page *page;

	page = pages + ((unsigned int)obj >> PAGE_SHIFT);
	if (!has_flag(page, _PAGE_SLUB))
		return free_pages((void *)((unsigned int)obj & ~((1 << PAGE_SHIFT) - 1)),
			page->private);

	return slub_free(page->virtual, obj);
}

