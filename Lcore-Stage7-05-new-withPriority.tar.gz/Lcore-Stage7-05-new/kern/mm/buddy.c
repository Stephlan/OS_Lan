#include "../../arch/arch.h"
#include "bootmm.h"
#include "buddy.h"
#include "../kern.h"
#include "../../tool/tool.h"

unsigned int kernel_start_pfn, kernel_end_pfn;

struct page *pages;
struct buddy_sys buddy;

void set_private(struct page *page, unsigned int order)
{
	page->private = order;
}

void init_pages(unsigned int start_pfn, unsigned int end_pfn)
{
	unsigned int index;
	for (index = start_pfn; index < end_pfn; ++index) {
		clean_flag(pages + index, -1);
		set_flag(pages + index, _PAGE_RESERVED);
		pages[index].refrence = 1;
		pages[index].virtual = (void *)-1;
		pages[index].private = -1;
		INIT_LIST_HEAD(&(pages[index].list));
	}
}

void buddy_info()
{
	unsigned int index;
	printk("Setup Buddy-system :\n");
	printk("\tstart page-frame number : %x\n", buddy.buddy_start_pfn);
	printk("\tend page-frame number : %x\n", buddy.buddy_end_pfn);
	for (index = 0; index <= MAX_BUDDY_ORDER; ++index) {
		printk("\t(%x)# : %x frees\n", index, buddy.freelist[index].nr_free);
	}
}

void init_buddy()
{
	unsigned int index = sizeof(struct page);
	
	pages = bootmm_alloc_pages(multiply(sizeof(struct page), boot_mm.max_pfn),
				_MM_KERNEL, 1 << PAGE_SHIFT);
	if (!pages) {
		printk("\nERROR : bootmm_alloc_pages failed!\n");
		die();
	}

	init_pages(0, boot_mm.max_pfn);
	
	kernel_start_pfn = 0;
	kernel_end_pfn = 0;
	for (index = 0; index < boot_mm.cnt_infos; ++index) {
		if (boot_mm.info[index].end > kernel_end_pfn)
			kernel_end_pfn = boot_mm.info[index].end;
	}
	kernel_end_pfn >>= PAGE_SHIFT;

	buddy.buddy_start_pfn = (kernel_end_pfn + (1 << MAX_BUDDY_ORDER) - 1)
			& ~((1 << MAX_BUDDY_ORDER) - 1);
	buddy.buddy_end_pfn = boot_mm.max_pfn & ~((1 << MAX_BUDDY_ORDER) - 1);
	for (index = 0; index <= MAX_BUDDY_ORDER; ++index) {
		buddy.freelist[index].nr_free = 0;
		INIT_LIST_HEAD(&(buddy.freelist[index].free_head));
	}
	buddy.start_page = pages + buddy.buddy_start_pfn;
	init_lock(&(buddy.lock));

	for (index = buddy.buddy_start_pfn; index < buddy.buddy_end_pfn; ++index) {
		__free_pages(pages + index, 0);
	}

	buddy_info();
}

unsigned int is_buddy(struct page *buddy, unsigned int order)
{
	return (buddy->private == order);
}

void __free_pages(struct page *page, unsigned int order)
{
	unsigned int page_idx, buddy_idx;
	unsigned int combined_idx, tmp;
	struct page *buddy_page;

	dec_refrence(page, 1);
	if (page->refrence)
		return;

	lockup(&buddy.lock);

	page_idx = page - buddy.start_page;
	while (order < MAX_BUDDY_ORDER) {
		buddy_idx = page_idx ^ (1 << order);
		buddy_page = page + (buddy_idx - page_idx);
		if (!is_buddy(buddy_page, order))
			break;
		list_del_init(&buddy_page->list);
		--buddy.freelist[order].nr_free;
		clear_order(buddy_page);
		combined_idx = buddy_idx & page_idx;
		page += (combined_idx - page_idx);
		page_idx = combined_idx;
		++order;
	}
	set_order(page, order);
	list_add(&(page->list), &(buddy.freelist[order].free_head));
	++buddy.freelist[order].nr_free;

	unlock(&buddy.lock);
}

struct page *__alloc_pages(unsigned int order)
{
	unsigned int current_order, size;
	struct page *page, *buddy_page;
	struct freelist *free;

	lockup(&buddy.lock);

	for (current_order = order; current_order <= MAX_BUDDY_ORDER; 
		++current_order) {
		free = buddy.freelist + current_order;
		if (!list_empty(&(free->free_head)))
			goto found;
	}
	
	unlock(&buddy.lock);
	return 0;
	
found:
	page = container_of(free->free_head.next, struct page, list);
	list_del_init(&(page->list));
	set_order(page, order);
	set_flag(page, _PAGE_ALLOCED);
	set_refrence(page, 1);
	--(free->nr_free);

	size = 1 << current_order;
	while (current_order > order) {
		--free;
		--current_order;
		size >>= 1;
		buddy_page = page + size;
		list_add(&(buddy_page->list), &(free->free_head));
		++(free->nr_free);
		set_order(buddy_page, current_order);
	}
	
	unlock(&buddy.lock);
	return page;
}

void *alloc_pages(unsigned int order)
{
	struct page *page = __alloc_pages(order);

	if (!page)
		return 0;

	return (void *)((page - pages) << PAGE_SHIFT);
}

void free_pages(void *addr, unsigned int order)
{
	__free_pages(pages + ((unsigned int)addr >> PAGE_SHIFT), order);
}

