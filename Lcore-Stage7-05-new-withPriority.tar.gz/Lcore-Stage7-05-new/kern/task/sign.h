#ifndef _LCORE_SIGN_H
#define _LCORE_SIGN_H

#define MAX_SIGNS (sizeof( unsigned int))

struct signal {
	
};

#endif

