#include "task.h"
#include "sched.h"
#include "../../arch/arch.h"
#include "../../tool/tool.h"
#include "../time/time.h"
#include "../../arch/intr.h"

struct list_head ready_tasks;
struct list_head block_tasks;
struct intr_work sched_work;
struct task_struct *current = NULL;

void sched_insert_head(struct list_head *head, struct list_head *sched)
{
	list_add(sched, head);
}

void sched_insert_tail(struct list_head *head, struct list_head *sched)
{
	list_add_tail(sched, head);
}

struct task_struct *sched_remove_first(struct list_head *head)
{
	struct task_struct *task;
	struct list_head *ptr;
	
	if (list_empty(head))
		return NULL;

	ptr = head->next;
	list_del_init(ptr);
	task = container_of(ptr, struct task_struct, sched);

	return task;
}

void sched_remove_by_task(struct list_head *head, struct task_struct *task)
{
	if (list_empty(&(task->sched)))
		return;

	list_del_init(&(task->sched));
}

void slice_sched(unsigned int *regs, unsigned int status, unsigned int errArg, unsigned int errPc)
{
	struct task_struct *next;
	struct task_struct *old;

	current->state = _TASK_READY;
	sched_insert_tail(&ready_tasks, &(current->sched));
	
	next = sched_remove_first(&ready_tasks);
	if (!next) {
		printk("scheduler : next task is NULL!\n");
		die();
	}

	if (next != current) {
		old = current;
		current = next;
		switch_to(&(old->context), &(current->context));
	}
}

void slice_timer_sched(unsigned int *regs, unsigned int status, unsigned int errArg, unsigned int errPc)
{
	--(current->counter);
	if (current->counter)
		return;

	current->counter = _DEFAULT_TICKS >> 1;
	slice_sched(regs, status, errArg, errPc);	
}

void priority_timer_shed(unsigned int *regs, unsigned int status, unsigned int errArg, unsigned int errPc)
{
	/*if(current->state!=_TASK_FINISHED){
		current->state=_TASK_FINISHED;
		printk("Switch task\n");
		return;
	}*/
	if(current->state!=_TASK_FINISHED){
		printk("Current state = %x\n",current->state);
		printk("Current state = %x\n",current->state);
		printk("Current state = %x\n",current->state);
		current->state++;
	}
	else priority_sched(regs, status, errArg, errPc);
}

void priority_sched(unsigned int *regs, unsigned int status, unsigned int errArg, unsigned int errPc)
{
	struct task_struct *next;
	struct task_struct *old;


	//sched_insert_tail(&ready_tasks, &(current->sched));	//Loop for test
	
	next = sched_remove_first(&ready_tasks);

	if (!next) {
		printk("scheduler : next task is NULL!\n");
		die();
	}

	if (next != current) {
		old = current;
		current = next;
		switch_to(&(old->context), &(current->context));
	}
}

void init_sched()
{
	INIT_LIST_HEAD(&ready_tasks);
	INIT_LIST_HEAD(&block_tasks);

	current = &(init->task);

	sched_work.work = priority_timer_shed;
	INIT_LIST_HEAD(&sched_work.node);
	if (register_work(&(sched_work.node), time_index))
		return;

	printk("Init Sched ok\n");
	printk("\tcurrent task : %x\n", current);
}

void priority_sort_head(struct list_head *head)
{
	struct list_head* pos;
	struct task_struct* task;
	struct task_struct* head_task;
	struct list_head* record=head;
	if(head==NULL)return;
	head_task=container_of(head->next,struct task_struct,sched);	//Dummy head
	printk("Now in priority_sort_head\n");
	list_for_each(pos, head){
		task = container_of(pos, struct task_struct, sched);
		printk("Current traversal: pid = %x . priority = %x .\n",task->pid,task->priority);
		printk("Head->Next(First): pid = %x . priority = %x .\n",head_task->pid,head_task->priority);
		if(task->priority<=head_task->priority)break;
	}
	pos->prev->next=head->next;
	head->prev=pos->prev;
	pos->prev=head;
	head->next=pos;
}
