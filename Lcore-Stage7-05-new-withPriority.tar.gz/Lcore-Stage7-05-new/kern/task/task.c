#include "task.h"
#include "vma.h"
#include "../../arch/page.h"
#include "../mm/slub.h"
#include "../mm/buddy.h"
#include "../../arch/arch.h"
#include "../../tool/tool.h"
#include "sched.h"

#define IDMAP_MAX 16
#define MAX_PID (IDMAP_MAX * sizeof( unsigned char))
//ÿbit��Ӧһ��id�������ܹ����Ա�ʾ128��id
//Ҳ����ͬʱ���֧��128������
static  unsigned char idmap[IDMAP_MAX];
static unsigned int bits_map[8] = {1, 2, 4, 8, 16, 32, 64, 128};

struct list_head tasks;

union task_union *init = NULL;

//��ȡһ�����õ�pid
 unsigned int get_emptypid()
{
	 unsigned int no = 0;
	 unsigned int tmp;
	unsigned int index, bits;
	for (index = 0; index < IDMAP_MAX; ++index) {
		tmp = idmap[index];
		for (bits = 0; bits < sizeof( unsigned char); ++bits) {
			if (!(tmp & 0x01)) {
				idmap[index] |= bits_map[bits];
				break;
			}
			tmp >>= 1;
			++no;
		}
		if (bits < sizeof( unsigned char))
			break;
	}

	return no;
}

void put_pid( unsigned int pid)
{
	unsigned int remain;
	unsigned int index = division(pid, sizeof( unsigned char), &remain);
	idmap[index] &= (~bits_map[remain - 1]);
}

unsigned int inavailed_pid( unsigned int pid)
{
	return (pid >= MAX_PID);
}

void add_tasks(struct list_head *node)
{
	list_add_tail(node, &tasks);
}

void del_tasks(struct list_head *node)
{
	if (list_empty(node))
		return;

	list_del_init(node);
}

void init_task(void *phy_code)
{
	INIT_LIST_HEAD(&tasks);
	memset(idmap, 0, 16 * sizeof( unsigned char));
	
	init = (union task_union *)(KERN_STACK_BOTTOM - KERN_STACK_SIZE);
	if (!init)
		goto error;
	
	init->task.pid = get_emptypid();
	if (inavailed_pid(init->task.pid)){
		printk("Invalid pid=%x",init->task.pid);		
		goto error;}
	printk("Fetch pid=%xinit_",init->task.pid);
	init->task.ppid = init->task.pid;
	init->task.state = _TASK_UNINIT;
	init->task.counter = _DEFAULT_TICKS;
	init->task.pgd = pgd;

	init->task.state=_TASK_UNINIT;
	init->task.flags=_FLAG_NULL;
	init->task.need_rescheduled=0;
	init->task.priority=_NORMAL_PRIORITY;
	init->task.next_task=NULL;
	init->task.prev_task=NULL;
	init->task.p_optr=&(init->task);
	init->task.p_pptr=&(init->task);
	init->task.p_cptr=NULL;

	memset(&(init->task.context), 0, sizeof(struct regs_context));

	INIT_LIST_HEAD(&(init->task.stack_vma_head));
	INIT_LIST_HEAD(&(init->task.user_vma_head));
	INIT_LIST_HEAD(&(init->task.heap_vma_head));
	INIT_LIST_HEAD(&(init->task.node));
	INIT_LIST_HEAD(&(init->task.sched));
	add_tasks(&(init->task.node));

	
	if (add_vmas(&(init->task), _TASK_CODE_START, PAGE_SIZE)) {
			printk("init_task : add_vmas failed!\n");
			die();
	}
	
	if (do_one_mapping(init->task.pgd, _TASK_CODE_START, 
		phy_code, USER_DEFAULT_ATTR)) {
		printk("Init task-0 failed : do_one_mapping failed!\n");
		die();
	}
	
	memset(init->task.sigaction, 0, MAX_SIGNS * sizeof(struct signal));
	init->task.state = _TASK_RUNNING;

	printk("Init task-0 ok :\n");
	printk("\tpid : %x\n", init->task.pid);
	printk("\tphy_code : %x\n", phy_code);
	printk("\tkernel stack's end at %x\n", init);
	return;
error:
	printk("Init task-0 fialed!\n");
	die();
}

void inc_refrence_by_pt( unsigned int *pt)
{
	 unsigned int index;

	for (index = 0; index < (PAGE_SIZE >> 2); ++index) {
		if (is_P(&(pt[index]))) {
			inc_refrence(pages + (pt[index] >> PAGE_SHIFT), 1);
		}
	}
}

void *copy_pagetables()
{
	 unsigned int *old_pgd = NULL;
	 unsigned int *pgd = NULL;
	 unsigned int *tmp_pt;
	 unsigned int *old_pt;
	 unsigned int index, ptnr, i_pte;
	 unsigned int attr;

	pgd = ( unsigned int *)kmalloc(PAGE_SIZE);
	if (pgd == NULL) {
		printk("copy_pagetables : kmalloc pgd failed!\n");
		goto error1;
	}

	old_pgd = current->pgd;
	memcpy(pgd, old_pgd, PAGE_SIZE);
	//�ں˲��ֵ�ҳ������
	for (index = (_USER_VIRT_START >> PGD_SHIFT), ptnr = 0; 
			index < (ROM_START >> PGD_SHIFT); ++index) {
		if (old_pgd[index]) {	// ������swap����ˣ��ں˲�֧��swap
			tmp_pt = ( unsigned int *)kmalloc(PAGE_SIZE);
			if (tmp_pt == NULL) {
				printk("copy_pagetables : kmalloc pt failed!\n");
				goto error2;
			}
			//������pde
			++ptnr;
			pgd[index] &= OFFSET_MASK;
			pgd[index] |= ( unsigned int)tmp_pt;
			//�����ҳ��
			old_pt = old_pgd[index] & (~OFFSET_MASK);
			memcpy(tmp_pt, old_pt, PAGE_SIZE);
			for (i_pte = 0; i_pte < (PAGE_SIZE >> 2); ++i_pte) {
				if (tmp_pt[i_pte]) {
					//ȡ��дȨ��(copy on write)
					clean_W(&(tmp_pt[i_pte]));
					clean_W(&(old_pt[i_pte]));
				}
			}
		}	
	}

	//�����ҳ�����ɹ��ˣ������޸���ҳ��
	//��Ҫ������Ӧҳ���refrence
	for (index = (_USER_VIRT_START >> PGD_SHIFT), ptnr = 0; 
			index < (ROM_START >> PGD_SHIFT); ++index) {
		if (old_pgd[index]) {
			inc_refrence_by_pt(old_pgd[index] & (~OFFSET_MASK));
		}
	}

	flush_tlb(NULL);
	
	return pgd;
error2:
	if (ptnr) {
		for (index = (_USER_VIRT_START >> PAGE_SHIFT);
			(index < (PAGE_SIZE >> 2)) && ptnr; ++index, --ptnr) {
			if (pgd[index]) {
				old_pt = old_pgd[index] & (~OFFSET_MASK);
				tmp_pt = pgd[index] & (~OFFSET_MASK);
				if (old_pt == tmp_pt)
					kfree(tmp_pt);
			}
		}
	}
error1:
	kfree(pgd);
	return NULL;
}

union task_union * copy_mem(unsigned int args, union task_union *old)
{
	union task_union *new = NULL;
	 unsigned int *pgd;
	 unsigned int new_pid = get_emptypid();
	if (inavailed_pid(new_pid)) {
		printk("copy_mem failed : inavailed new pid\n");
		goto error1;
	}
	
	new = (union task_union *)kmalloc(sizeof(union task_union));
	if (!new) {
		printk("copy_mem failed : kmalloc return NULL\n");
		goto error2;
	}

	if (!(pgd = copy_pagetables())) {
		printk("copy_mem failed : copy_pagetables failed\n");
		goto error3;
	}
	
	memcpy(new, old, sizeof(union task_union));
	new->task.state = _TASK_BLOCKED;
	new->task.ppid = old->task.pid;
	new->task.pid = new_pid;
	new->task.counter = _DEFAULT_TICKS;
	new->task.pgd = pgd;

	new->task.state=_TASK_UNINIT;
	new->task.flags=_FLAG_NULL;
	new->task.need_rescheduled=0;
	new->task.priority=old->task.priority;	//Inherit
	new->task.next_task=NULL;
	new->task.prev_task=NULL;
	new->task.p_optr=&(old->task);
	new->task.p_pptr=&(old->task);
	new->task.p_cptr=NULL;

	old->task.p_cptr=&(new->task);

	INIT_LIST_HEAD(&(new->task.node));
	INIT_LIST_HEAD(&(new->task.sched));
	memcpy(&(new->task.context), args, sizeof(struct regs_context));
	new->task.context.ra = &_ctx_restore;
	
	add_tasks(&(new->task.node));
	
	//Insert new task sched & reschedule
	sched_insert_head(&ready_tasks, &(new->task.sched));
	priority_sort_head(&ready_tasks);
	printk("pid = %x",new->task.pid);
	sleep(10000);	
	
	return new;
error3:
	kfree(new);
error2:
	put_pid(new_pid);
error1:
	return NULL;
}

unsigned int do_fork(unsigned int *args)
{
	union task_union *new;
	struct regs_context *ctx;
	unsigned int res;
		
	
	new = copy_mem(args, (union task_union *)current);
	ctx = (struct regs_context *)(&(new->task.context));
	if (!new) {
		res = -1;
	} else {
		res = new->task.pid;
		ctx->v0 = 0;
	}

	return res;
}

void sleep(unsigned int ms)
{
	ms=ms*500;
	while(ms--);
}
