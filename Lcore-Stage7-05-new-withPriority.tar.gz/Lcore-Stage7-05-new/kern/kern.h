#ifndef _LCORE_KERN_H
#define _LCORE_KERN_H

#define container_of(ptr, type, member) \
    ((type *)((unsigned char *)ptr - (unsigned char *)&(((type *)0)->member)))

#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))

#define NULL 0

/*
*list_head ѭ��˫������
*prev : ָ��ǰһ��Ԫ��
*next : ָ����һ��Ԫ��
*/
struct list_head {
    struct list_head *prev;
    struct list_head *next;
};


/*
* �жϴ����ṹ
*/

typedef void (*intr_fn)(unsigned int *regs, unsigned int status, unsigned int errArg, unsigned int errPc);

struct intr_work {
	intr_fn work;
	struct list_head node;
};

struct intr_block {
	intr_fn entry_fn;
	struct list_head head;
};

#endif

