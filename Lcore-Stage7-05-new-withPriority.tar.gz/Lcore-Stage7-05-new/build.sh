#!/bin/sh

clear
make clean
make
make boot
make disassembly
