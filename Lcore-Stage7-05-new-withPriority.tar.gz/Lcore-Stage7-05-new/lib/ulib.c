#include "ulib.h"

/*
* api
*/
unsigned int fork()
{
	unsigned int val;
	
	enter_syscall0(SYS_FORK);
	asm volatile (
		"move %0,$v0"
		:"=r"(val)
	);
	
	return val;
}

void putch(unsigned int ch, unsigned int bg, unsigned int fg)
{
	enter_syscall3(ch, bg, fg, SYS_PUTCH);
}


/*
* printf����ʵ��
*/
static unsigned char *imap = "0123456789ABCDEF";

static unsigned int print_char(unsigned char ch)
{
	putch(ch, COLOR_BLACK, COLOR_WHITE);
	return 1;
}

static unsigned int print_str(unsigned char *s)
{
	while (*s) {
		print_char(*s);
		++s;
	}
}

static unsigned int print_binary(unsigned int i)
{
	if (!i) {
		print_str("0b0");
		return;
	}
	print_binary(i >> 1);
	print_char((unsigned char)(imap[i%2]));
}

static unsigned int print_hex(unsigned int i)
{
	if (!i) {
		print_str("0x0");
		return;
	}
	print_hex(i >> 4);
	print_char((unsigned char)(imap[i%16]));
}

unsigned int printf(unsigned char *fmt, ...)
{
	unsigned int argint;
	unsigned char argch;
	unsigned char *argstr;
	unsigned char *pfmt;
	unsigned int index;
	va_list vp;
	
	va_start(vp, fmt);
	pfmt = fmt;
	index = 0;
	while (*pfmt) {
		if (*pfmt == '%') {
			switch (*(++pfmt)) {
				case 'c':
				case 'C':
					argch = va_arg(vp, unsigned int);
					index += print_char(argch);
					break;
				case 's':
				case 'S':
					argstr = va_arg(vp, unsigned char *);
					index += print_str(argstr);
					break;
				case 'b':
				case 'B':
					argint= va_arg(vp, unsigned int);
					index += print_binary(argint);
					break;
				case 'x':
				case 'X':
					argint= va_arg(vp, unsigned int);
					index += print_hex(argint);
					break;
				case '%':
					index += print_char('%');
					break;
				default:
					break;
			}
			++pfmt;
		} else {
			index += print_char(*pfmt);
			++pfmt;
		}
	}
	va_end(vp);
	return index;
}

