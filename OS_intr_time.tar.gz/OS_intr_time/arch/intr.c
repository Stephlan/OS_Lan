#include "arch.h"
#include "intr.h"
#include "../kern/list.h"

struct intr_block interrupt[_INTR_MAX];

void init_exint()
{
	int entry=_INTR_ENTRY;
	int index=0;
	for(index=0;index<_INTR_MAX;index++){
		interrupt[index].entry_fn=0;				//Initialize each interrupt function
		INIT_LIST_HEAD(&(interrupt[index].head));	//Initialize heads of interrupts
	}
	memcpy(EXCEPT_ENTRY,&_exint_handler,(char*)&_end_ex-(char*)&_exint_handler);	//Copy Exception & Interrupt information to EXCEPT_ENTRY(Address) 
	asm volatile(
		"mtc0 %0,$3"
		:
		:"r"(entry)
	);	
	disable_intr(_INTR_GLOBAL|_INTR_CLOCK|_INTR_KEYB|_INTR_SPI);	//Disable interrupts
}

void do_interrupt(unsigned int status,unsigned int errArg,unsigned int errPc,unsigned int* regs)		//Execute responding interrupts
{
	unsigned int icr,indexl;
	if(!(status&_INTR_FLAG))return;
	icr=get_icr()/get_ier();
	if(icr&_INTR_CLOCK){		//Clock interrupts
		if(interrupt[0].entry_fn){
			interrupt[0].entry_fn();	//If there is a legal function of interrupt, do it.
		}
		clean_icr(_INTR_CLOCK);
	}
	if(icr&_INTR_KEYB){			//Keyboard interrupts
		if(interrupt[3].entry_fn){
			interrupt[3].entry_fn();	//If there is a legal function of interrupt, do it.
		}
		clean_icr(_INTR_KEYB);
	}
	if(icr&_INTR_SPI){			//SPI interrupts
		if(interrupt[5].entry_fn){
			interrupt[5].entry_fn();	//If there is a legal function of interrupt, do it.
		}
		clean_icr(_INTR_SPI);
	}
}

void enable_intr(unsigned int val)
{
	unsigned int old;
	
	asm volatile (
		"mfc0 %0,$4"
		:"=r"(old)
	);
	
	old |= val;
	
	asm volatile (
		"mtc0 %0,$4"
		:
		:"r"(old)
	);
}

void disable_intr(unsigned int val)
{
	unsigned int old;
	
	asm volatile (
		"mfc0 %0,$4"
		:"=r"(old)
	);
	
	old &= (~val);
	
	asm volatile (
		"mtc0 %0,$4"
		:
		:"r"(old)
	);
}

unsigned int get_timer()
{
	unsigned int interval;
	
	asm volatile (
		"mfc0 %0,$7"
		:"=r"(interval)
	);

	return interval;
}

void set_timer(unsigned int interval)
{
	interval &= 0x00000FFF;
	
	asm volatile (
		"mtc0 %0,$7"
		:
		:"r"(interval)
	);
}

unsigned int get_ier()
{
	unsigned int ier;

	asm volatile (
		"mfc0 %0,$4"
		:"=r"(ier)
	);

	return ier;
}

void set_ier(unsigned int val)
{
	asm volatile (
		"mtc0 %0,$4"
		:
		:"r"(val)
	);
}



unsigned int get_icr()
{
	unsigned int icr;

	asm volatile (
		"mfc0 %0,$5"
		:"=r"(icr)
	);

	return icr;
}

void clean_icr(unsigned int val)
{
	val &= 0x7fffffff;
	
	asm volatile (
		"mtc0 %0,$5"
		:
		:"r"(val)
	);
}

/*
* ����1��ʾʧ�ܣ�0��ʾ�ɹ�
*/
unsigned int register_handler(intr_fn handler,unsigned int index)
{
	if(interrupt[index].entry_fn){
		printk("KERN Error: Enrty_fn Existed. Register Failed.[INT : %x ]\n",index);
		return 1;
	}
	interrupt[index].entry_fn=handler;
	return 0;
}

void unregister_handler(unsigned int index)
{
	if(!interrupt[index].entry_fn){
		printk("KERN Warning: NO handler to be unregistered.[INT : %x ]\n",index);
		return;
	}
	interrupt[index].entry_fn=0;
}
	
unsigned int register_work(struct list_head *work_node ,unsigned int index)	//Change to handler_work???
{
	if(!interrupt[index].entry_fn){
		printk("KERN Error:Not defined handler.[INT : %x ]\n",index);
		return 1;
	}
	list_add_tail(work_node,&interrupt[index].head);
	//Add work_node in front of the head
	return 0;
}

void unregister_work(struct list_head *work_node)
{
	if(!list_empty(work_node)){
		printk("KERN Warning: No work found.\n");
		return;
	}		
	//________________________________________________________
	//!!!HERE EMPTY OR !EMPTY
	//������������������������������������������������������������������������������������������������������������������	
	list_del_init(work_node);
}

