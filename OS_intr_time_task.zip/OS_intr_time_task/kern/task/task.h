//Each of unsigned int variable in the following struct stands for a register
//Every register we have is 32 bits
//Register Structure
struct regs_context{
	unsigned int v0,v1;
	unsigned int a0,a1,a2,a3;
	unsigned int t0,t1,t2,t3,t4,t5,t6,t7;
	unsigned int s0,s1,s2,s3,s4,s5,s6,s7;
	unsigned int t8,t9;
	unsigned int gp,sp,fp,ra,k0,k1;
	unsigned int epc,ear;
};

//Task Infomation Structure
//Every process will have a task struct and the struct will be freed when the process terminates
struct task_struct{
	unsigned int user_stack;	//Top pointer position of user stack
	unsigned int user_code;		//INITIAL Linear Address in USER Mode
	unsigned int pid;			//Process ID
	unsigned int state;			//_TASK_UNINIT _TASK_READY _TASK_RUNNING _TASK_BLOCKED
	unsigned int counter;		//Number of CPU time slicers
	unsigned int* pgd;			//Lead to index of process pages

	struct list_head sched;		//To -> Shedule List
	struct list_head node;		//To -> Process List
	struct list_head stack_vma_head;	//USER Mode Stack
	struct list_head user_vma_head;		//USER Code/Static Data Area
	struct list_head heap_vma_head;		//USER Heap
};

union task_union{	//Union of tasks
	struct task_struct task;
	unsigned char kernel_stack[KERN_STACK_SIZE];	//Room for KERNEL Mode Processes
};

struct vma{	//Linear Area in virtual memory
	struct list_head node;	//Linking node
	unsigned int start;	//Start address
	unsigned int cnt;	//Size of pages
	unsigned int vend;	//End address
}
