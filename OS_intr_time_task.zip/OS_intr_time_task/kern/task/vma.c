struct vma *new_vma(unsigned int va,unsigned int vend)	//Create new vma;
{
	struct vma* tmp;
	temp=kmalloc(sizeof(struct vma));
	if(!tmp){	//Memory Allocation
		return NULL;
	}

	INIT_LIST_HEAD(&(tmp->node));	//Node initialization
	tmp->start=va;
	tmp->vend=vend;
	temp->cnt=((vend-va)>>PAGE_SHIFT)+1;

	return temp;
}


//Cut up vma at the point va
//TODO Textbook Spelling Mistake
struct vma* seprate_vma(struct vma* vma, unsigned int va)
{
	struct vma* new;
	if(!(new=new_vma(va,vma->vend))){	//Check memory allocation
		printk("seperate_vma: new_vma failed!\n");
		return NULL;
	}
	vma->vend=va-1;
	list_add(&(new->node),vma->node.next);	//Add to list - Similar to Register 
	return new;
}

//To make sure if linear range sent is legal -- 0:legal 1:illegal
//To align 
unsigned int verify_vma(struct task_struct* task,unsigned int* va,unsigned int* tend,struct list_head** target)
{
	*target=NULL;
	(*va)&=~(PAGE_SIZE-1);
	(*vend)+=(PAGE_SHIFT-1);
	(*vend)&=(PAGE_SIZE-1);
	(*vend)--;
	if((*va)<_KERNEL_VIRT_END){
		printk("add_vms:va(%x) invalid kernel space!\n",*va);
		return 1;
	}else if((*va)<_TASK_CODE_START){
		if((*vend)>=_TASK_CODE_START){
			printk("add_vms:vma(%x:%x) exceed!\n",*va,*vend);
			return 1;
		}else{	//valid
			*target=&(task->stack_vma_head);
		}
	}else if((*va)<_TASK_HEAP_END){
		if((*vend)>=_TASK_HEAP_END){
			printk("add_vmas:vma(%x,%x) exceed!\n",(*va),(*vend));
			return 1;
		}else{	//valid
			*target=&(task->user_vma_head);
		}
	}else if((*va)<ROM_START){
		if((*vend)>=ROM_START){
			prink("add_vmas:vma(%x,%x) exceed!\n",(*va),(*vend));
			return 1;
		}else{
			*target=&(task->heap_vma_head);
		}
	}else{	//>=ROM_START
		printk("add_vmas:va(%x inavailed (rom/io space)!\n");
		return 1;
	}
	return 0;
}

//1:error 0:success
//To insert a vma in linear address area
//task: target process  va: start address  size: vma size
unsigned int add_vmas(struct task_struct * task, unsigned int va, unsigned int size)
{
	struct list_head* target;
	struct list_head* pos;
	struct list_head* n;
	struct vma* tmp;
	struct list_head *prev;
	unsigned int vend=va+size;

	if(verify_vma(task,&va,&vend,&target)){	//To check whether the inputs are valid
		return 1;
	}

	prev=target;
	list_for_each_safe(pos,n,target){		//Macro
		//Traversal to find whether there is a vma supporting merging or overwrting
		tmp=container_of(pos,struct vma,node);	//Macro - Obtain vma of a list node 
		if(va<tmp->start){	//Create a new node
			if(vend<tmp->start){
				if((vend+1)==temp->start){	//CONTINUOUS
					tmp->start=va;
					tmp->cnt=((tmp->vend-tmp->start)>>PAGE_SHIFT)+1;	//To modify linear range of vma_tmp so that it starts at vma_new->start(va)
					goto ok;
				}else{						//NOT CONTINUOUS
					prev=tmp->node.prev;
					goto new;
				}
			}else if(vend>=tmp->vend){		//Delete vma_tmp for it is contained by vma_new & Execute next loops
				del_vma(tmp);
				continue;
			}else{							//Merge tmp and new by extending tmp
				tmp->start=va;
				tmp->cnt=((tmp->vend-tmp->start)>>PAGE_SHIFT)+1;
				goto ok;
			}
		}else if(va<tmp->vend){				//vma_new included
			if(vend<=tmp->vend){
				goto ok;
			}else{							//Overwrite directly
				//va=tmp->vend+1;	//low 12 bits : 1
				va=tmp->start;
				del_vma(tmp);
				continue;
			}
		}else{								//After tmp section
			if((va-1)==tmp->vend){			//CONTINUOUS
				va=tmp->start;
				del_vma(tmp);
				continue;
			}else{							//NOT CONTINUOUS insert in next loops
				prev=&(tmp->node);
				continue;
			}
		}
	}

new:
	if(!(tmpe=new_vma(va,vend))){
		printk("insert_vma : new_vma failed\n");
		return 1;
	}
	list_add(&(tmp->node),prev);
ok:
	return 0;
}

unsigned int delete_vmas(struct task_struct *task, unsigned int va,unsigned int vend)	//To delete a range in an EXISTED linear range
{
	struct list_head* pos;
	struct vma* tmp,* n;
	struct list_head* list;
	if(verify_vma(task, &va, &vend, &list))return 1;	//To check whether inputs are legal
	list_for_each(post, list){
		tmp=container_of(pos,struct vma,node);
		if(va<tmp->start){
			return 1;
		}else if(va==tmp->start){
			if(vend==tmp->vend){
				del_vma(tmp);
				return 0;
			}else if(vend<tmp->vend){
				tmp->start=vend+1;	//Modify tmp->start directly
				return 0;
			}else{
				return 1;
			}
		}else if(va<tmp->vend){
			if(vend==tmp->vend){
				tmp->vend=va-1;
				return 0;
			}else if(vend<tmp->vend){
				n=seprate_vma(tmp,va);
				if(!n){
					printk("delete_vmas: seperate_vma failed!\n");
					return 1;
				}
				tmp=n;
				n=seprate_vma(n,vend+1);
				if(!n){
					printk("delete_vmas: seperate_vma failed!\n");
					return 1;
				}
				del_vma(tmp);
				return 0;
			}else{
				return 1;
			}
		}else{
			continue;
		}
	}
	return 0;
}