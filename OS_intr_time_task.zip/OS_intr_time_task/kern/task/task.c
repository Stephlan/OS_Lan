void init_task(void* phy_code)
{
	INIT_LIST_HEAD(&tasks);
	memset(idmap,0,16*sizeof(unsigned char));
	init=(union task_union*)(KERN_STACK_BOTTOM-KERN_STACK_SIZE);
	if(!init)goto error;
	init->task.pid=get_emptypid();
	if(inavailed_pid(init->task.pid))goto error;
	init->task.parent=init->task.pid;
	init->task.user_stack=_TASK_USER_STACK;
	init->task.user_code=_TASK_CODE_START;
	init->task.state=_TASK_UNINIT;
	init->task.counter=_DEFAULT_TICKS;
	init->task.pgd=pgd;

	INIT_LIST_HEAD(&(init->task.stack_vma_head));
	INIT_LIST_HEAD(&(init->task.user_vma_head));
	INIT_LIST_HEAD(&(init->task.heap_vma_head));
	INIT_LIST_HEAD(&(init->task.task.node));
	INIT_LIST_HEAD(&(init->task.task.sched));
	add_tasks(&(init->task.node));

	if(add_vmas(&(init->task),init->task.user_code,PAGE_SIZE)){
		printk("init_task : add_vmas failed\n");
		die();
	}

	if(do_one_mapping(init->task.pgd,init->task.user_code,phy_code,USER_DEFAULT_ATTR)){
		printk("Init failed: do_one_mapping failed.\n");
		die();
	}

	memset(init->task.sigaction,0,MAX_SIGNS*sizeof(struct signal));
	init->task.state=_TASK_RUNNING;		//RUN!
	printk("Init task OK:\n");
	printk("\tpid:%x\n",init_task.pid);
	printk("\tphy_code:%x\n",phy_code);
	printk("\tkernel stack's end at %x\n",init);
	return;

error:
	printk("Init task failed.\n");
	die();
}

unsigned int get_emptypid()	//Get an empty ID
{
	unsigned int Number=0;
	unsigned int tmp;
	unsigned int index,bits;
	for(index=0;index<IDMAP_MAX;index++){
		tmp=idmap[index];		//Obtain a byte in idmap
		for(bits=0;bits<sizeof(unsigned char);bits++){	//Check every bit of the byte to find if it is 0
														//0 stands for not occupied
			if(!(tmp&0x01)){
				idmap[index]|=bits_map[bits];
				break;
			}
			tmp>>=1;
			Number++;
		}
		if(bits<sizeof(unsigned char))break;
	}
	return Number;
}

//pgd->page index base address
//va-> virtual linear range of inserting relation
//pa-> physical address of inserting relation
//attr-> inserting relation attributes
unsigned int do_one_mapping(unsigned int*pgd, unsigned int va, unsigned int pa, unsigned int attr)
{
	unsigned int pde_index=(va>>PGD_SHIFT)&INDEX_MASK;
	unsigned int pte_index=(va>>PTE_SHIFT)&INDEX_MASK;
	unsigned int *pt;
	pt=(unsigned int *)kmalloc(PAGE_SIZE);
	if(pt==NULL)return 1;
	//To fill page table
	//RANK 1: sth about physical address and attributes
	//pt->RANK 2 page table
	pgd[pde_index]=(unsigned int)pt&(~OFFSET_MASK);
	pgd[pde_index]|=attr;
	//RANKD 2: 
	pa&=(~OFFSET_MASK);
	pa|=attr;
	pt[pte_index]=pa;
	return 0;
}

//Fork a process
void do_fork(unsigned int *args)
{
	union task_union* new;
	struct regs_context *ctx;
	unsigned int res;
	ctx=(struct regs_context*)args;
	new=copy_mem((union task_union*)current);	//Kernel stack space of new process
	if(!new){
		ctx->v0=-1;
	}else{
		ctx->v0=new->task.pid;	
		ctx=(unsigned int)args-(unsigned int)current;
		ctx=(struct regs_context*)((unsigned int)new+(unsigned int)ctx);
		ctx->v0;
	}
}

union task_union* copy_mem(union task_union* old)	//old CONTEXT of father process
{
	union task_union* new=NULL;
	unsigned int* pgd;
	unsigned int new_pid=get_emptypid();
	if(inavailed_pid(new_pid)){
		printk("copy_mem failed:inavailed new pid\n");
		goto error1;
	}

	new=(union task_union*)kmalloc(sizeof(union task_union));
	if(!new){
		printk("copy_mem failed: kmalloc return NULL.\n");
		goto error2;
	}
	if(!(pgd=copy_pagetables())){
		printk("copy_mem failed:copy_pagetables failed\n");
		goto error3;
	}

	memcpy(new,old,sizeof(union task_union));
	//Set attributes of new process
	new->task.state=_TASK_BLOCKED;
	new->task.parent=old->task.pid;
	new->task.pid=new_pid;
	new->task.counter=_DEFAULT_TICKS;
	new->task.pgd=pgd;
	//Register Heads
	INIT_LIST_HEAD(&(new->task.node));
	INIT_LIST_HEAD(&(new->task.sched));
	add_tasks(&(new->task.node));
	sched_insert_head(&ready_tasks,&(new->task.node));
	new->task.state=_TASK_READY;
	return new;

error3:
	kfree(new);
error2:
	put_pid(new_pid);
error1:
	return NULL;
}

void* copy_pagetables()
{
	unsigned int* old_pgd=NULL;
	unsigned int* pgd=NULL;
	unsigned int* tmp_pt;
	unsigned int* old_pt;
	unsigned int index,ptnr;
	unsigned int attr;

	pgd=(unsigned int*)kmalloc(PAGE_SIZE);
	//RANK 1 page table for subprocess
	if(pgd==NULL)goto error1;
	old_pgd=current->pgd;
	memcpy(pgd,old_pgd,PAGE_SIZE);
	ptnr=0;
	index=_USER_VIRT_START>>PAGE_SHIFT;
	for(;index<(PAGE_SHIFT>>2);index++){
		if(old_pgd[index]){
			//Swap not supported
			tmp_pt=(unsigned int*)kmalloc(PAGE_SIZE);
			if(tmp_pt==NULL)goto error2;
			++ptnr;
			pgd[index]&=OFFSET_MASK;
			pgd[index]|=(unsigned int)tmp_pt;
			old_pt=old_pgd[index]&(~OFFSET_MASK);
			//Fill in the new page table
			memcpy(tmp_pt,old_pt,PAGE_SIZE);
			//Erase writing privilege
			clean_W(&(pgd[index]));
		}
	}
	ptnr=0;
	index=_USER_VIRT_START>>PAGE_SHIFT;
	for(;index<(PAGE_SIZE>>2);index++){
		if(old_pgd[index])clean_W(&(old_pgd[index]));	//Deny writing of parent process
		if(is_P(&old_pgd[index])){
			inc_refrence(pages+(old_pgd[index]>>PAGE_SHIFT),1);
			inc_refrence_by_pt(old_pgd[index]&(~OFFSET_MASK));
		}
	}
	return pgd;
error2:
	if(ptnr){
		index=_USER_VIRT_START>>PAGE_SHIFT;
		for(;index<(PAGE_SIZE>>2)&&ptnr;index++,ptnr--){
			if(pgd[index]){
				old_pt=old_pgd[index]&(~OFFSET_MASK);
				tmp_pt=pgd[index]&(~OFFSET_MASK);
				if(old_pt==tmp_pt)kfree(tmp_pt);
			}
		}
	}	

error1:
	kfree(pgd);
	return NULL;
}

